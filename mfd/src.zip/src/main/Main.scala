import crossover.{TwoPointCrossoverEngine}
import fitness.SineFunction
import mutation.SimpleMutationEngine
import selection.RouletteWheelSelectionEngine
import solver.GASolver


object Main extends App {
  var popSize = 10
  var genotypeLength = 8

  var fitnessFunc = new SineFunction()
  var selector = new RouletteWheelSelectionEngine(true)
  var crossEngine = new TwoPointCrossoverEngine(0.8)
  var mutationEngine = new SimpleMutationEngine(0.005)

  var solver = new GASolver(popSize, genotypeLength, fitnessFunc, selector,
                            crossEngine, mutationEngine)

  time{ solver.solve(100) }

  def time[R](block: => R) = {
    val t0 = System.currentTimeMillis()
    block // call-by-name
    val t1 = System.currentTimeMillis()
    println("Execution time: "+(t1-t0)+" ms")
  }

}


